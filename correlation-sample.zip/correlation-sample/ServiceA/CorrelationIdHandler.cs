using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

public class CorrelationIdHandler : DelegatingHandler
{
    private readonly IHttpContextAccessor _httpContextAccessor;
    private const string HeaderName = "X-Correlation-ID";

    public CorrelationIdHandler(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
    {
        var context = _httpContextAccessor.HttpContext;

        if (context != null && context.Items.ContainsKey(HeaderName))
        {
            var correlationId = context.Items[HeaderName]?.ToString();
            if (!string.IsNullOrWhiteSpace(correlationId))
            {
                if (request.Headers.Contains(HeaderName))
                {
                    request.Headers.Remove(HeaderName);
                }
                request.Headers.Add(HeaderName, correlationId);
            }
        }

        return base.SendAsync(request, cancellationToken);
    }
}
