using System.Net;
using Serilog;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;

var builder = WebApplication.CreateBuilder(args);

// Serilog (console, structured)
Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();

builder.Host.UseSerilog();

// Add services
builder.Services.AddHttpContextAccessor();
builder.Services.AddHealthChecks();

// Register CorrelationId handler and HttpClient for ServiceB
builder.Services.AddTransient<CorrelationIdHandler>();
builder.Services.AddHttpClient("ServiceBClient", client =>
{
    client.BaseAddress = new Uri("http://localhost:6000/");
    client.Timeout = TimeSpan.FromSeconds(10);
})
.AddHttpMessageHandler<CorrelationIdHandler>();

// OpenTelemetry - minimal setup (console exporter for demo)
builder.Services.AddOpenTelemetry()
    .WithTracing(tracerProviderBuilder =>
    {
        tracerProviderBuilder
            .AddAspNetCoreInstrumentation()
            .AddHttpClientInstrumentation()
            .AddConsoleExporter();
    })
    .WithMetrics(mb =>
    {
        mb.AddAspNetCoreInstrumentation();
    });

var app = builder.Build();

// Middleware
app.UseMiddleware<CorrelationIdMiddleware>();

app.MapHealthChecks("/health");

app.MapGet("/forward", async (IHttpClientFactory httpClientFactory, HttpContext httpContext, string? name) =>
{
    name ??= "anonymous";
    var client = httpClientFactory.CreateClient("ServiceBClient");

    var resp = await client.GetAsync($"/process?name={WebUtility.UrlEncode(name)}");
    var content = await resp.Content.ReadAsStringAsync();

    // Access correlation id from HttpContext (set by middleware)
    var correlationId = httpContext.Items["X-Correlation-ID"]?.ToString();

    return Results.Ok(new
    {
        forwardedTo = "ServiceB",
        serviceBResponse = content,
        correlationId
    });
});

app.Run(""http://localhost:5000"");
