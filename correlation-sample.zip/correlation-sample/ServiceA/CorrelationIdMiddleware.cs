using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;

public class CorrelationIdMiddleware
{
    private readonly RequestDelegate _next;
    private const string HeaderName = "X-Correlation-ID";

    public CorrelationIdMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task Invoke(HttpContext context)
    {
        string correlationId;

        if (context.Request.Headers.TryGetValue(HeaderName, out var cid) && !string.IsNullOrWhiteSpace(cid))
        {
            correlationId = cid.ToString();
        }
        else
        {
            correlationId = Guid.NewGuid().ToString("D");
            context.Request.Headers[HeaderName] = correlationId;
        }

        // Expose to the rest of the pipeline
        context.Items[HeaderName] = correlationId;

        // Ensure response contains header
        context.Response.OnStarting(() =>
        {
            if (!context.Response.Headers.ContainsKey(HeaderName))
                context.Response.Headers[HeaderName] = correlationId;
            return Task.CompletedTask;
        });

        await _next(context);
    }
}
