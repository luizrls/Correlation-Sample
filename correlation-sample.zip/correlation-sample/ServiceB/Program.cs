using Serilog;
using OpenTelemetry.Trace;
using OpenTelemetry.Metrics;

var builder = WebApplication.CreateBuilder(args);

Log.Logger = new LoggerConfiguration()
    .Enrich.FromLogContext()
    .WriteTo.Console()
    .CreateLogger();

builder.Host.UseSerilog();

builder.Services.AddHealthChecks();
builder.Services.AddHttpContextAccessor();

// OpenTelemetry - minimal setup (console exporter)
builder.Services.AddOpenTelemetry()
    .WithTracing(tp =>
    {
        tp.AddAspNetCoreInstrumentation()
          .AddConsoleExporter();
    })
    .WithMetrics(mb =>
    {
        mb.AddAspNetCoreInstrumentation();
    });

var app = builder.Build();

app.UseMiddleware<CorrelationIdMiddleware>();

app.MapHealthChecks("/health");

app.MapGet("/process", (HttpContext httpContext, string? name) =>
{
    name ??= "anonymous";
    var correlationId = httpContext.Items["X-Correlation-ID"]?.ToString();

    // Example structured log with correlation id
    Log.ForContext("CorrelationId", correlationId)
       .Information("Processing {Name} in ServiceB", name);

    return Results.Ok(new { processed = name, correlationId });
});

app.Run(""http://localhost:6000"");
