# Correlation ID Sample (ServiceA -> ServiceB)

This sample contains two minimal ASP.NET Core 8 microservices demonstrating:
- Correlation ID generation and propagation via `X-Correlation-ID`
- Middleware to set/read correlation id
- HttpClient DelegatingHandler to propagate the header
- Serilog for structured logging
- Basic OpenTelemetry tracing/metrics configuration (console exporter for demo)
- Health checks

Folders:
- ServiceA: exposes `/forward?name=...` which calls ServiceB
- ServiceB: exposes `/process?name=...` which returns the correlation id it received

How to run (requires .NET 8 SDK):
1. cd /path/to/correlation-sample/ServiceB
   dotnet run
2. cd /path/to/correlation-sample/ServiceA
   dotnet run
3. Call ServiceA:
   curl "http://localhost:5000/forward?name=alice"

Notes:
- This is a minimal, didactic sample. In production, secure sensitive settings and use proper exporters (Jaeger/OTLP/Prometheus).
